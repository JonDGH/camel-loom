package camel.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.util.thread.ThreadPool;

public class NonPooledThreadPool implements ThreadPool {

	public static ThreadPool ofVirtual() {
		return withFactory(Thread.ofVirtual().factory());
	}

	public static ThreadPool ofPlatform() {
		return withFactory(Thread.ofPlatform().factory());
	}

	public static ThreadPool withFactory(ThreadFactory f) {
		return new NonPooledThreadPool(Executors.newThreadExecutor(f));
	}

	private final ExecutorService executor;

	private NonPooledThreadPool(ExecutorService executor) {
		this.executor = executor;
	}

	@Override
	public void execute(Runnable command) {
		executor.execute(command);
	}

	@Override
	public int getIdleThreads() {
		return 0;
	}

	@Override
	public int getThreads() {
		return 0;
	}

	@Override
	public boolean isLowOnThreads() {
		return false;
	}

	@Override
	public void join() throws InterruptedException {
		executor.awaitTermination(14, TimeUnit.DAYS);
	}

}

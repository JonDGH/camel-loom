package camel.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.impl.DefaultCamelContext;

public class Client {
	//private static ExecutorService exec = Executors.newCachedThreadPool();
	private static ExecutorService exec = Executors.newThreadExecutor(Thread.ofVirtual().factory());
	//private static ExecutorService exec = Executors.newThreadExecutor(Thread.ofPlatform().factory());

	private static AtomicInteger reponse = new AtomicInteger(0);
	private static long startTime;

	public static void main(String[] args) throws Exception {
		try (CamelContext context = new DefaultCamelContext()) {
			context.addRoutes(new MyRouteBuilder());
			context.start();
			ProducerTemplate prod = context.createProducerTemplate();
			prod.sendBody("direct:send", null);
			startTime = System.currentTimeMillis();
			for (int i = 0; i < 50_000; i++) {
				exec.execute(() -> prod.sendBody("direct:send", null));
			}
			exec.shutdown();
			exec.awaitTermination(1, TimeUnit.DAYS);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	private static class MyRouteBuilder extends RouteBuilder {

		@Override
		public void configure() throws Exception {
			onException(HttpOperationFailedException.class).log("Error: ${exception}");
			from("direct:send").setHeader(Exchange.HTTP_URI).constant("http://localhost:8080")
					.setHeader(Exchange.HTTP_METHOD).constant("GET").toD("${header." + Exchange.HTTP_URI + "}")
					.process(exchange -> {
						notifyResponseCode(exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class));
					});
		}
	}

	private static void notifyResponseCode(Integer header) {
		int count = reponse.incrementAndGet();
		if( count % 1000 == 0 ) {
			System.out.println( "Received: " + count + " (elapsed time: " + (System.currentTimeMillis() - startTime) + "ms)");
		}
	}

}

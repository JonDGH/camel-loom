package camel.test;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jetty9.JettyHttpComponent9;
import org.apache.camel.http.base.HttpOperationFailedException;
import org.apache.camel.impl.DefaultCamelContext;

public class Server {
	public static void main(String[] args) throws Exception {
		try (CamelContext context = new DefaultCamelContext()) {
			context.addRoutes(new MyRouteBuilder());
			context.getComponent("jetty", JettyHttpComponent9.class).setThreadPool(NonPooledThreadPool.ofVirtual());
			//context.getComponent("jetty", JettyHttpComponent9.class).setThreadPool(NonPooledThreadPool.ofPlatform());
			context.start();
			Thread.sleep(10000000);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	private static class MyRouteBuilder extends RouteBuilder {
		@Override
		public void configure() throws Exception {
			onException(HttpOperationFailedException.class).log("Error: ${exception}");
			from("jetty:http://0.0.0.0:8080").process(exchange -> {
				//System.out.println(Thread.currentThread());
				exchange.getMessage().setBody("{hello: \"world\"}");
			});
		}
	}
}
